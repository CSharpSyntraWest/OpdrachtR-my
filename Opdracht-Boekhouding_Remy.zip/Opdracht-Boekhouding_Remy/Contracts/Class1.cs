﻿using System;

namespace Contracts
{
    public class Class1
    {
    }
}
