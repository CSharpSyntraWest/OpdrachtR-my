﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts
{
    public interface IRepositoryManager
    {
  
        //Hier aan te vullen:
        //IGrootBoekRepository GrootboekRekening { get; }
        //IJournaal Journaal { get; }
        //IJournaalPost JournaalPost { get; }
        //IJournaalPostLijn JournaalPostLijn { get; }
        void Save();
    }
}
