﻿using System;
using System.Collections.Generic;

namespace Entities.Models
{
    public partial class DbJournaalPostHist
    {
        public int Id { get; set; }
        public int? JournaalPostId { get; set; }
        public int RekeningId { get; set; }
        public string Code { get; set; }
        public int? DocId { get; set; }
        public string Omschrijving { get; set; }
        public double Bedrag { get; set; }
        public string CD { get; set; }
        public double? Debet { get; set; }
        public double? Credit { get; set; }
        public string Referentie { get; set; }
        public int VolgNr { get; set; }
    }
}
