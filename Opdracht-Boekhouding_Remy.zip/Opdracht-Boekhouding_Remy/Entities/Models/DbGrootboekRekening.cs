﻿using System;
using System.Collections.Generic;

namespace Entities.Models
{
    public partial class DbGrootboekRekening
    {
        public DbGrootboekRekening()
        {
            JournaalPostLijn = new HashSet<DbJournaalPostLijn>();
        }

        public int Id { get; set; }
        public string Code { get; set; }
        public string Naam { get; set; }
        public string BeginWaarde { get; set; }
        public double? Saldo { get; set; }
        public double? Subtotaal { get; set; }
        public string Type { get; set; }
        public string Klasse { get; set; }
        public string Klasse2 { get; set; }
        public string Klasse3 { get; set; }
        public string SorteerKolom { get; set; }

        public virtual ICollection<DbJournaalPostLijn> JournaalPostLijn { get; set; }
    }
}
