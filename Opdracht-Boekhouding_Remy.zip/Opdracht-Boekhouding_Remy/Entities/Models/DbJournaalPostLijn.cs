﻿using System;
using System.Collections.Generic;

namespace Entities.Models
{
    public partial class DbJournaalPostLijn
    {
        public int Id { get; set; }
        public int JournaalPostId { get; set; }
        public string Code { get; set; }
        public int RekeningId { get; set; }
        public string Omschrijving { get; set; }
        public string Cd { get; set; }
        public double Bedrag { get; set; }
        public double? Debet { get; set; }
        public double? Credit { get; set; }
        public string Referentie { get; set; }
        public int? VolgNr { get; set; }

        public virtual DbJournaalPost JournaalPost { get; set; }
        public virtual DbGrootboekRekening Rekening { get; set; }
    }
}
