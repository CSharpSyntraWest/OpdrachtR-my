﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Boekhouding.Models
{
    //public enum JournaalItemType
    //{
    //   JournaalPost,
    //   Transactie
    //}
    public class JournaalType
    {
        public int Id { get; set; }
        //public int ItemType {get;set;}
        public string Naam { get; set; }
    }
}
