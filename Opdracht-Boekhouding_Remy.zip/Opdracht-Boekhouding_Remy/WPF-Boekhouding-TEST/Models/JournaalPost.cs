﻿using System;
using System.Collections.Generic;

namespace Boekhouding.Models
{
    public partial class JournaalPost
    {
        public JournaalPost()
        {
            JournaalPostLijn = new HashSet<JournaalPostLijn>();
        }

        public int Id { get; set; }
        public DateTime? BoekDatum { get; set; }
        public int? DocId { get; set; }
        public string Omschrijving { get; set; }
        public string Referentie { get; set; }
        public int VolgNr { get; set; }
        public bool IsGeboekt { get; set; }
        public int JournaalId { get; set; }
        public virtual Journaal Journaal{ get; set; }
        public virtual ICollection<JournaalPostLijn> JournaalPostLijn { get; set; }
    }
}
