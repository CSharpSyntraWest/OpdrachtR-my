﻿using System;
using System.Collections.Generic;

namespace Boekhouding.Models
{
    public partial class GrootboekRekening
    {
        public enum BalansType
        { 
            Activa,
            Passiva
        }
        public GrootboekRekening()
        {
            JournaalPostLijn = new HashSet<JournaalPostLijn>();
        }

        public int Id { get; set; }
      //  public string Code { get; set; }
        public string Naam { get; set; }
        public double? BeginSaldo { get; set; }
        public double? Saldo { get; set; }
        public BalansType Type { get; set; }


        public virtual ICollection<JournaalPostLijn> JournaalPostLijn { get; set; }
    }
}
