﻿using System;
using System.Collections.Generic;

namespace Boekhouding.Models
{
    public enum CreditOfDebet
    { 
        Credit,
        Debet
    }
    public partial class JournaalPostLijn
    {
        public int Id { get; set; }
        public int JournaalPostId { get; set; }
        //public int Code { get; set; }
        public int RekeningId { get; set; }
        public string Omschrijving { get; set; }
        public CreditOfDebet CreditOfDebet { get; set; }
        //public double Bedrag { get; set; }
        public double? Debet { get; set; }
        public double? Credit { get; set; }
        public string Referentie { get; set; }
        public int? VolgNr { get; set; }

        public virtual JournaalPost JournaalPost { get; set; }
        public virtual GrootboekRekening Rekening { get; set; }
    }
}
