﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Boekhouding.Models
{

    public class Journaal
    {
        public Journaal()
        {
            JournaalPosten = new HashSet<JournaalPost>();
        }

        public int Id { get; set; }
        public string Naam { get; set; }
        public int Boekjaar { get; set; }
       // public int JournaalType { get; set; }
       // public JournaalType JournaalType { get; set; }
       public virtual ICollection<JournaalPost> JournaalPosten { get; set; }

        //public override string ToString()
        //{
        //    return JournaalType.ToString();
        //}

    }
}
