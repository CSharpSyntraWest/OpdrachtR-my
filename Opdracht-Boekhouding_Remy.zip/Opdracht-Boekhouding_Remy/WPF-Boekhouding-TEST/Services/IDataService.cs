﻿using Boekhouding.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Boekhouding.Services
{
    public interface IDataService
    {
        IList<GrootboekRekening> GeefAlleGrootboekRekeningen();
        IList<Journaal> GeefAlleJournalen();
        IList<JournaalPost> GeefAlleJournaalPosten();
        IList<JournaalPost> GeefJournaalPostenVoorJournaalId(int journaalId);
        IList<JournaalPostLijn> GeefJournaalPostLijnenVoorPostId(int journaalPostId);
        IList<JournaalPost> VoegJournaalPostToe(JournaalPost journaalPost);
        IList<JournaalPost> WijzigJournaalPost(JournaalPost journaalPost);
        IList<JournaalPost> VerwijderJournaalPost(JournaalPost journaalPost);
    }
 
}
