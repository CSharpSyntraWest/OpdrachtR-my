﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Boekhouding.Services
{
    public enum DialogResults
    {
        Undefined,
        Yes,
        No,
        Ok,
        Cancel
    }
}
