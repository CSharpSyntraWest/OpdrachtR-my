﻿using AutoMapper;
using Boekhouding.Models;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Boekhouding.Models.GrootboekRekening;

namespace Boekhouding.Services
{
    public class MockDataService : IDataService
    {
        #region fields
        private IList<GrootboekRekening> _grootboekRekeningen;
        private IList<Journaal> _journalen;
        private RepositoryContext _db = new RepositoryContext();
        private IList<JournaalPost> _journaalPosten;
        private IList<JournaalPostLijn> _journaalPostLijnen;
        #endregion
        public MockDataService()
        {
            InitLists();
        }
        private void InitLists()
        {
            InitGrootboekrekeningen();
            InitJournalen();
            InitJournaalPosten();
            InitJournaalPostLijnen();
        }

        private void InitJournaalPostLijnen()
        {


            //Id JournaalPostId  Code RekeningId  Omschrijving CD  Bedrag Debet   Credit Referentie  VolgNr

            _journaalPostLijnen = new List<JournaalPostLijn>() {
                new JournaalPostLijn(){ Id=  1 ,JournaalPostId= 1 ,RekeningId=  416 ,Omschrijving="Diverse vorderingen" ,CreditOfDebet=CreditOfDebet.Debet  , Debet=67500 ,Referentie=  "Ref1" ,     VolgNr=  1 },// , RekeningId =168
                new JournaalPostLijn(){ Id= 2 ,JournaalPostId=  1 ,RekeningId=   101 ,Omschrijving= "Niet - opgevraagd kapitaal(-) : "  , CreditOfDebet=CreditOfDebet.Credit  , Credit=67500 ,Referentie=  "Ref2" , VolgNr= 2},//, RekeningId = 5 
                new JournaalPostLijn(){ Id= 3 ,JournaalPostId=  2 ,RekeningId=   101 ,Omschrijving=" Niet - opgevraagd kapitaal(-)" ,  CreditOfDebet=CreditOfDebet.Debet , Debet= 100000  ,Referentie=  "Ref3" , VolgNr=3},//, RekeningId = 5 
                new JournaalPostLijn(){ Id= 4  ,JournaalPostId= 2 ,RekeningId=   100,Omschrijving= "Geplaatst kapitaal: "  , CreditOfDebet=CreditOfDebet.Credit , Credit=    100000  ,Referentie=  "Ref4" , VolgNr= 4},// RekeningId = 4  ,
                new JournaalPostLijn(){ Id= 5 ,JournaalPostId=  3 ,RekeningId=   340, Omschrijving=" Handelsgoederen, Aanschaffingswaarde" ,CreditOfDebet=CreditOfDebet.Debet , Debet= 12500   ,Referentie=  "Ref5" , VolgNr= 5},//RekeningId = 140 ,
                new JournaalPostLijn(){ Id= 6 ,JournaalPostId=  3 ,RekeningId=   24 , Omschrijving= "Meubilair en rollend materieel" , CreditOfDebet=CreditOfDebet.Debet , Debet=  7500    ,Referentie=  "Ref6" , VolgNr= 6},//RekeningId = 72 ,
                new JournaalPostLijn(){ Id= 7 ,JournaalPostId=  3 ,RekeningId=   411, Omschrijving="Terug te vorderen BTW"   ,CreditOfDebet=CreditOfDebet.Debet , Debet=  4200    ,Referentie=  "Ref7" ,  VolgNr= 7},//RekeningId = 162 ,
                new JournaalPostLijn(){ Id= 8  ,JournaalPostId= 3 ,RekeningId=   489 , Omschrijving="Andere diverse schulden", CreditOfDebet=CreditOfDebet.Credit , Credit=    4200   ,Referentie=  "Ref8" , VolgNr=     8},//RekeningId =225 ,
                new JournaalPostLijn(){ Id= 9  ,JournaalPostId= 3 ,RekeningId=   101 , Omschrijving="Niet - opgevraagd kapitaal(-) : ",CreditOfDebet=CreditOfDebet.Credit  ,Credit= 20000 ,Referentie=  "Ref9" ,     VolgNr=   9},//RekeningId =5   ,
                new JournaalPostLijn(){ Id= 10 ,JournaalPostId= 4 ,RekeningId=   5500 , Omschrijving="Rekening - courant"   ,CreditOfDebet=CreditOfDebet.Debet , Debet= 67500   ,Referentie=  "Ref10" ,VolgNr=   10},//RekeningId = 253 ,
                new JournaalPostLijn(){ Id= 11 ,JournaalPostId= 4 ,RekeningId=   416 , Omschrijving="Diverse vorderingen:"   ,CreditOfDebet=CreditOfDebet.Credit  ,Credit=  67500  ,Referentie=  "Ref11" ,     VolgNr=     11},//RekeningId =168 ,
                new JournaalPostLijn(){ Id= 12 ,JournaalPostId= 5 ,RekeningId=   410 , Omschrijving= "Opgevraagd, niet - gestort kapitaal" ,CreditOfDebet=CreditOfDebet.Debet    , Debet= 10000 ,Referentie=  "Ref12" ,     VolgNr=        12},//RekeningId =161,
                new JournaalPostLijn(){ Id= 13 ,JournaalPostId= 5 ,RekeningId=   101 , Omschrijving= "Niet - opgevraagd kapitaal(-)"  ,CreditOfDebet=CreditOfDebet.Credit , Credit=    10000 ,Referentie=  "Ref13" ,     VolgNr=     13},//RekeningId =5  ,
                new JournaalPostLijn(){ Id= 14 ,JournaalPostId= 6 ,RekeningId=   5500, Omschrijving="Rekening - courant"    ,CreditOfDebet=CreditOfDebet.Debet  ,Debet= 8000    ,Referentie=  "Ref14" ,     VolgNr=        14},//RekeningId = 253 ,
                new JournaalPostLijn(){ Id= 15,JournaalPostId=  6 ,RekeningId=  410 , Omschrijving="Opgevraagd, niet - gestort kapitaal"  ,CreditOfDebet=CreditOfDebet.Credit ,Credit=    8000    ,Referentie=  "Ref15" ,     VolgNr=    15}//RekeningId =161 ,
            };
        }

        private void InitJournaalPosten()
        {
            //Id BoekDatum   DocId Omschrijving    Referentie VolgNr  JournaalId
            _journaalPosten = new List<JournaalPost>() {        
                new JournaalPost(){  Id=1 , BoekDatum=new DateTime(2021,1,4),  DocId=   1  , Omschrijving="Storting op geblokkeerde bankrekening" ,   Referentie="Referentie1",VolgNr=   1 ,JournaalId=  1 ,IsGeboekt=true},
                new JournaalPost(){  Id=2 ,BoekDatum=new DateTime(2021,1,4),  DocId=    2 , Omschrijving="Verlijden oprichtingsakte" ,   Referentie="Referentie2",VolgNr=   2 ,JournaalId=  1,IsGeboekt=false },
                new JournaalPost(){  Id=3 ,BoekDatum=new DateTime(2021,1,5),  DocId=    3  , Omschrijving="Inbreng in natura" ,   Referentie="Referentie3",VolgNr=   3 ,JournaalId=  1 ,IsGeboekt=false},
                new JournaalPost(){  Id=4 ,BoekDatum=new DateTime(2021,1,5),  DocId=    4  , Omschrijving="Deblokkering van de rekening" ,   Referentie="Referentie4",VolgNr=   4 ,JournaalId=  1 ,IsGeboekt=false},
                new JournaalPost(){  Id=5 ,BoekDatum=new DateTime(2021,1,6),  DocId=    5  , Omschrijving="Opvraging 10 %" ,   Referentie="Referentie5",VolgNr=   5 ,JournaalId=  1,IsGeboekt=false },
                new JournaalPost(){  Id=6 ,BoekDatum=new DateTime(2021,1,6),  DocId=    6  , Omschrijving="Storting van 8 %, 1AH in gebreke" ,   Referentie="Referentie6",VolgNr=   6 ,JournaalId=  1,IsGeboekt=false }
            };

        }

        private void InitJournalen()
        {
            _journalen = new List<Journaal>() {
            new Journaal(){ Id=1, Naam="Diversen",Boekjaar=   2021 },//, JournaalType=   1 },
            new Journaal(){ Id=2 , Naam="Aankopen",Boekjaar=    2021 },//  , JournaalType=   3 },
            new Journaal(){ Id=3 , Naam="Verkopen",Boekjaar=    2021 },// , JournaalType=    4 }
            };
           // IList<DbJournaal> dbJournalen = (IList<DbJournaal>)_db.Journaal.ToList();
            var config = new MapperConfiguration(cfg => cfg.CreateMap<DbJournaal, Journaal>());
            //var config = new MapperConfiguration(cfg => {
            //    cfg.CreateMap<DbJournaalType, JournaalType>();
            //    cfg.CreateMap<DbJournaal, Journaal>();
            //    //cfg.AddProfile<BoekhoudingProfile>();
            //});
            //var mapper = new Mapper(config);
     
            //List<Journaal> journalen = mapper.Map<IList<DbJournaal>, List<Journaal>>(dbJournalen);
            //_journalen = journalen;
        }
        //internal class BoekhoudingProfile : Profile
        //{
        //    public BoekhoudingProfile()
        //    {
        //        CreateMap<int, JournaalItemType>()
        //            //.ConvertUsingEnumMapping(opt => opt
        //                // optional: .MapByValue() or MapByName(), without configuration MapByValue is used
        //                .MapValue(Source.First, Destination.Default)
        //            )
        //            .ReverseMap(); // to support Destination to Source mapping, including custom mappings of ConvertUsingEnumMapping
        //    }
        //}
        private void InitGrootboekrekeningen()
        {
            _grootboekRekeningen = new List<GrootboekRekening>() {
                            new GrootboekRekening(){ Id=  100,Naam=" Geplaatst kapitaal",BeginSaldo=      100000 ,Saldo= 0 ,Type=  BalansType.Passiva },//Id= 4 , Code
                            new GrootboekRekening(){ Id=  101 ,Naam="Niet - opgevraagd kapitaal(-)",BeginSaldo= 2500  ,Saldo= 0 ,Type=BalansType.Passiva },// 5 , Code= 
                            new GrootboekRekening(){ Id=  24 ,Naam= "Meubilair en rollend materieel" ,BeginSaldo=     7500  ,Saldo=  0  ,Type=BalansType.Activa },//72 , Code=
                            new GrootboekRekening(){ Id=  340,Naam= "Handelsgoederen, Aanschaffingswaarde",BeginSaldo=        12500 ,Saldo=  0  ,Type=BalansType.Activa  },//140 , Code=
                            new GrootboekRekening(){ Id=  410 ,Naam="Opgevraagd, niet - gestort kapitaal",BeginSaldo=       2000  ,Saldo=  0  ,Type=BalansType.Activa  },//161 , Code=
                            new GrootboekRekening(){ Id=  411,Naam= "Terug te vorderen BTW" ,BeginSaldo=      4200  ,Saldo=  0 ,Type=BalansType.Activa },//162 , Code=
                            new GrootboekRekening(){ Id=  416,Naam= "Diverse vorderingen",BeginSaldo=     0  ,Saldo= 0  ,Type=BalansType.Activa  },//168, Code= 
                            new GrootboekRekening(){ Id=  489 ,Naam="Andere diverse schulden" ,BeginSaldo=    4200  ,Saldo=  0 ,Type=BalansType.Passiva },//225, Code=
                            new GrootboekRekening(){ Id=  5500 ,Naam= "Rekening - courant" ,BeginSaldo=       75500  ,Saldo= 0  ,Type=BalansType.Activa }//253, Code=
            };
            //new GrootboekRekening(){ Id= Id, Code=   ,Naam= ,BeginWaarde= ,Saldo= ,Subtotaal=    ,Type= Klasse  Klasse2 Klasse3 SorteerKolom
        }

        public IList<GrootboekRekening> GeefAlleGrootboekRekeningen()
        {
               return _grootboekRekeningen;
        }

        public IList<Journaal> GeefAlleJournalen()
        {
            return _journalen;
        }
        public IList<JournaalPost> GeefAlleJournaalPosten()
        {
            return _journaalPosten;
        }
        public IList<JournaalPost> GeefJournaalPostenVoorJournaalId(int journaalId)
        {
            return (IList<JournaalPost>)_journaalPosten.Where(p => p.JournaalId == journaalId).ToList();
        }
        public IList<JournaalPostLijn> GeefJournaalPostLijnenVoorPostId(int journaalPostId)
        {
            return (IList<JournaalPostLijn>)_journaalPostLijnen.Where(l => l.JournaalPostId== journaalPostId).ToList();
        }

        public IList<JournaalPost> WijzigJournaalPost(JournaalPost journaalpost)
        {
            int index = _journaalPosten.IndexOf(journaalpost);
            if (index >= 0)
            {
                _journaalPosten[index] = journaalpost;
            }
            return (IList<JournaalPost>)_journaalPosten;
        }


        public IList<JournaalPost> VoegJournaalPostToe(JournaalPost journaalpost)
        {
            
            int newId = (_journaalPosten.Count > 0) ? _journaalPosten.Max(b => b.Id) + 1 : 1;
            journaalpost.Id = newId;
            journaalpost.DocId = newId;
            _journaalPosten.Add(journaalpost);
            return _journaalPosten;
        }

        public IList<JournaalPost> VerwijderJournaalPost(JournaalPost journaalpost)
        {
            _journaalPosten.Remove(journaalpost);
            return _journaalPosten;
        }
    }
}
