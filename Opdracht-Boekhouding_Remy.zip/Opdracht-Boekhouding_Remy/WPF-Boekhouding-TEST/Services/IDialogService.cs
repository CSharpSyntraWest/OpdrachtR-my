﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Boekhouding.Services
{
    public interface IDialogService
    {
        T OpenDialog<T>(DialogViewModelBase<T> viewModel);
    }
}
