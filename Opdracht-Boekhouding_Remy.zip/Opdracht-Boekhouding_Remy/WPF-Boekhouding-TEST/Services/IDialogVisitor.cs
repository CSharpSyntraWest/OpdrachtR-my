﻿using System;

namespace Boekhouding.Services
{
    public interface IDialogVisitor
    {
        object DynamicVisit(Object data);
    }
}
