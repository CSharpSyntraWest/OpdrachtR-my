﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Boekhouding.Utilities
{
    public static class Constants
    {
        public const string IE_path = @"C:\Program Files\Internet Explorer\IExplore.exe";
    }
}
