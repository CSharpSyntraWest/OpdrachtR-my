﻿using Boekhouding.Services;
using Boekhouding.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Boekhouding.ViewModels
{
    public class MainViewModel:ObservableObject
    {
        private IDialogService _dialogService;
        //private IDialogVisitor _visitor;
        private IDataService _dataService;
        private GrootboekRekeningenViewModel _grootboekVM;
        private JournalenViewModel _journalenVM;
        private JournaalPostenViewModel _journaalPostVM;


        public MainViewModel()
        {
            _dialogService = new DialogService();
            //_visitor = new DialogVisitor();
            _dataService = new MockDataService();
            GrootboekVM = new GrootboekRekeningenViewModel(_dataService);
            JournalenVM = new JournalenViewModel(_dataService);
            JournaalPostVM = new JournaalPostenViewModel(_dataService, _dialogService);

        }
        public JournalenViewModel JournalenVM
        {
            get { return _journalenVM; }
            set { OnPropertyChanged(ref _journalenVM, value); }
        }
        public JournaalPostenViewModel JournaalPostVM
        {
            get { return _journaalPostVM; }
            set { OnPropertyChanged(ref _journaalPostVM, value); }
        }

        public GrootboekRekeningenViewModel GrootboekVM
        {
            get { return _grootboekVM; }
            set { OnPropertyChanged(ref _grootboekVM, value); }
        }

    }
}
