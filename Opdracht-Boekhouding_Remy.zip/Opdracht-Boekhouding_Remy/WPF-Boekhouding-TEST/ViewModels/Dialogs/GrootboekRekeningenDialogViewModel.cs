﻿using Boekhouding.Models;
using Boekhouding.Services;
using Boekhouding.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Boekhouding.ViewModels
{
    public class GrootboekRekeningenDialogViewModel : DialogViewModelBase<DialogResults>
    {

        private IDataService _dataService;
        private ObservableCollection<GrootboekRekening> _grootboekRekeningen;
        private GrootboekRekening _selectedRekening;
        public ICommand SelectCommand { get; private set; }
        public ICommand CancelCommand { get; private set; }
        public GrootboekRekeningenDialogViewModel(IDataService dataService,string title, GrootboekRekening grootboekRekening) : base(title,  "Grootboekrekeningen")
        {
            _dataService = dataService;
            GrootboekRekeningen = new ObservableCollection<GrootboekRekening>(_dataService.GeefAlleGrootboekRekeningen());
            if (grootboekRekening != null) SelectedRekening = grootboekRekening;
            // if (GrootboekRekeningen.Count() > 0) SelectedRekening = GrootboekRekeningen[0];
            
            SelectedRekening = grootboekRekening;
            SelectCommand = new RelayCommand<IDialogWindow>(Select);
            CancelCommand = new RelayCommand<IDialogWindow>(Cancel);
        }
        private void Cancel(IDialogWindow window)
        {
            Answer = null;
            CloseDialogWithResult(window, DialogResults.Cancel);
            
        }
        private void Select(IDialogWindow window)
        {
            Answer = SelectedRekening;
            CloseDialogWithResult(window, DialogResults.Cancel);
        }

        public GrootboekRekening SelectedRekening

        {
            get { return _selectedRekening; }
            set { OnPropertyChanged(ref _selectedRekening, value); }
        }
        public ObservableCollection<GrootboekRekening> GrootboekRekeningen
        {
            get { return _grootboekRekeningen; }
            set { OnPropertyChanged(ref _grootboekRekeningen, value); }
        }
    }
}
