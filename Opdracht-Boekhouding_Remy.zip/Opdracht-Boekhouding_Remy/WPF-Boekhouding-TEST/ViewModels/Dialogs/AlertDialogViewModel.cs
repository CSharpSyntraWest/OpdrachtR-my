﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Boekhouding.Services;
using Boekhouding.Utilities;

namespace Boekhouding.ViewModels
{
    public class AlertDialogViewModel:DialogViewModelBase<DialogResults>
    {
        public ICommand OKCommand { get; private set; }
        public AlertDialogViewModel(string title, string message):base(title,message)
        {
            OKCommand = new RelayCommand<IDialogWindow>(OK);
        }
        private void OK(IDialogWindow window)
        {
            CloseDialogWithResult(window, DialogResult);
        }
    }
}
