﻿using Boekhouding.Models;
using Boekhouding.Services;
using Boekhouding.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Boekhouding.ViewModels
{
    public class JournaalPostenViewModel:ObservableObject
    {
        private IDialogService _dialogService;
        private IDataService _dataService;
        private ObservableCollection<JournaalPost> _journaalPosten;
        private ObservableCollection<JournaalPostLijn> _journaalPostLijnen;
        private JournaalPost _selectedJournaalPost;
        private JournaalPostLijn _selectedJournaalPostLijn;
       
        private string _errorTekst;

        public JournaalPostenViewModel(IDataService dataService, IDialogService dialogService)
        {
            _dialogService = dialogService;
            _dataService = dataService;
            JournaalPosten = new ObservableCollection<JournaalPost>(_dataService.GeefJournaalPostenVoorJournaalId(1));//Diversen Journaal
            if (JournaalPosten.Count() > 0) SelectedJournaalPost = JournaalPosten[0];
            GeefJournaalPostLijnen();
            BoekJournaalPostCommand = new RelayCommand(BoekJournaalPost);
            ToonJournaalPostenCommand = new RelayCommand(GeefJournaalPosten);
            ToonJournaalPostLijnenCommand = new RelayCommand(GeefJournaalPostLijnen);
            ToonGrootboekRekeningenCommand = new RelayCommand(ShowGrootBoekRekeningenDialog);
            AddJournaalPostLijnCommand = new RelayCommand(JournaalPostLijnToevoegen);
            UpdateJournaalPostLijnCommand = new RelayCommand(JournaalPostLijnWijzigen);
            DeleteJournaalPostLijnCommand = new RelayCommand(JournaalPostLijnVerwijderen);

        }

        private void JournaalPostLijnVerwijderen()
        {
            if (SelectedJournaalPost.IsGeboekt) //Kan bv niet vewijderd worden indien het reeds is geboekt: Alert boodschap geven
            {
                AlertDialogViewModel alertDialog = new AlertDialogViewModel("Journaalpost", $"Geboekte journaalpost DocId='{SelectedJournaalPost.DocId}' kan niet worden verwijderd.");
                _dialogService.OpenDialog(alertDialog);
            }
            else 
            {
                //Vraag bevestiging om bier te verwijderen via YesNo Dialoogvenster
                YesNoDialogViewModel yesNodialog = new YesNoDialogViewModel("Verwijderen JournaalPost", $"Bent u zeker dat u Journaalpost DocId='{SelectedJournaalPost.DocId}' wilt verwijderen?");

                DialogResults result = _dialogService.OpenDialog(yesNodialog);
                // Debug.WriteLine(result);
                if (result == DialogResults.Yes)
                {
                    JournaalPosten = new ObservableCollection<JournaalPost>(_dataService.VerwijderJournaalPost(SelectedJournaalPost));
                    if (JournaalPosten.Count > 0) SelectedJournaalPost = JournaalPosten[0];
                }
            }
        }

        private void JournaalPostLijnWijzigen()
        {
            _dataService.WijzigJournaalPost(SelectedJournaalPost);
        }

        private void JournaalPostLijnToevoegen()
        {
            JournaalPost journaalPost = new JournaalPost() { BoekDatum = DateTime.Today, Omschrijving = "NA", Referentie = "NA", JournaalId = 1, IsGeboekt = false, JournaalPostLijn = new List<JournaalPostLijn>() };
            JournaalPosten = new ObservableCollection<JournaalPost>(_dataService.VoegJournaalPostToe(journaalPost));
        }

        private void GeefJournaalPostLijnen()
        {
            if (SelectedJournaalPost != null)
            {
                JournaalPostLijnen = new ObservableCollection<JournaalPostLijn>(_dataService.GeefJournaalPostLijnenVoorPostId(SelectedJournaalPost.Id));
                if (JournaalPostLijnen.Count() > 0) SelectedJournaalPostLijn = JournaalPostLijnen[0];
            }
        }
        private void GeefJournaalPosten()
        {
            if (SelectedJournaalPost == null && JournaalPosten.Count > 0)
                SelectedJournaalPost = JournaalPosten[0];
            JournaalPosten = new ObservableCollection<JournaalPost>(_dataService.GeefJournaalPostenVoorJournaalId(1));//Diversen Journaal
        }

        public ICommand AddJournaalPostLijnCommand { get; private set; }
        public ICommand UpdateJournaalPostLijnCommand { get; private set; }
        public ICommand DeleteJournaalPostLijnCommand { get; private set; }
        public ICommand ToonJournaalPostenCommand { get; private set; }
        public ICommand ToonJournaalPostLijnenCommand { get; private set; }
        public ICommand ToonGrootboekRekeningenCommand { get; private set; }
        private void BoekJournaalPost()
        {
            if(SelectedJournaalPost != null)
            {
                double? somCredit = 0.0;
                double? somDebet = 0.0;
                foreach( JournaalPostLijn lijn in JournaalPostLijnen)
                {
                    somCredit += lijn.Credit?? 0.0;
                    somDebet += lijn.Debet ?? 0.0;
                }
                if (somCredit == somDebet)
                {
                    SelectedJournaalPost.IsGeboekt = true;
                    
/*                    OnPropertyChanged(nameof(SelectedJournaalPost))*/;
                    JournaalPosten = new ObservableCollection<JournaalPost>(_dataService.WijzigJournaalPost(SelectedJournaalPost));
                    ShowAlert("Boeking Journaalpost", $"Journaalpost met DocId={SelectedJournaalPost.DocId} is geboekt");

                }  
                else
                {
                    //Debug.Write("NOK");
                    ErrorTekst = $"som Credit ({somCredit}) is niet gelijk aan som Debet ({somDebet}) bedragen";
                    ShowAlert("Boeking Journaalpost", $"Journaalpost met DocId={SelectedJournaalPost.DocId} kan niet geboekt worden:\n" + ErrorTekst);
                }
            }
        }
        private void ShowAlert(string titel, string melding)
        {
            AlertDialogViewModel dialog = new AlertDialogViewModel(titel, melding);
            DialogResults result = _dialogService.OpenDialog(dialog);
            Debug.WriteLine(result);
        }
        private void ShowGrootBoekRekeningenDialog()
        {
            DialogViewModelBase<DialogResults> dialog;
            if (SelectedJournaalPostLijn != null)
            {
                dialog = new GrootboekRekeningenDialogViewModel(_dataService,"GrootboekRekeningen", SelectedJournaalPostLijn.Rekening);
            }
            else
            {
                dialog = new AlertDialogViewModel("Grootboekrekening", "Selecteer journaalpost-lijn");
            }
            DialogResults result = _dialogService.OpenDialog(dialog);
            if (dialog.Answer != null)
            {
                SelectedJournaalPostLijn.RekeningId = ((GrootboekRekening)dialog.Answer).Id;
                OnPropertyChanged(nameof(SelectedJournaalPostLijn));
            }
            //Debug.WriteLine(dialog.Answer);
        }
        public string ErrorTekst {
            get { return _errorTekst; }
            set { OnPropertyChanged(ref _errorTekst, value);}
        }
        public ICommand BoekJournaalPostCommand { get; private set; }

        public JournaalPost SelectedJournaalPost

        {
            get { return _selectedJournaalPost; }
            set { OnPropertyChanged(ref _selectedJournaalPost, value);
                  GeefJournaalPostLijnen();
            }
        }

        public ObservableCollection<JournaalPost> JournaalPosten
        {
            get { return _journaalPosten; }
            set { OnPropertyChanged(ref _journaalPosten, value); }
        }
        public ObservableCollection<JournaalPostLijn> JournaalPostLijnen
        {
            get { return _journaalPostLijnen; }
            set { OnPropertyChanged(ref _journaalPostLijnen, value); }

        }
        public JournaalPostLijn SelectedJournaalPostLijn

        {
            get { return _selectedJournaalPostLijn; }
            set { OnPropertyChanged(ref _selectedJournaalPostLijn, value); }
        }
    }
}
