﻿using Boekhouding.Models;
using Boekhouding.Services;
using Boekhouding.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Boekhouding.ViewModels
{
    public class GrootboekRekeningenViewModel:ObservableObject
    {

        private IDataService _dataService;
        private ObservableCollection<GrootboekRekening> _grootboekRekeningen;
        private GrootboekRekening _selectedRekening;
        public GrootboekRekeningenViewModel(IDataService dataService)
        {
            _dataService = dataService;
            GrootboekRekeningen = new ObservableCollection<GrootboekRekening>(_dataService.GeefAlleGrootboekRekeningen());
            if (GrootboekRekeningen.Count() > 0) SelectedRekening = GrootboekRekeningen[0];
        }
        public GrootboekRekening SelectedRekening
        
        {
                get { return _selectedRekening; }
                set { OnPropertyChanged(ref _selectedRekening, value); }
        }
        public ObservableCollection<GrootboekRekening> GrootboekRekeningen
        {
            get { return _grootboekRekeningen; }
            set { OnPropertyChanged(ref _grootboekRekeningen, value); }
        }
    }
}
