﻿using Boekhouding.Models;
using Boekhouding.Services;
using Boekhouding.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Boekhouding.ViewModels
{
    public class JournalenViewModel:ObservableObject
    {
        private IDataService _dataService;
        private ObservableCollection<Journaal> _journalen;
      //  private ObservableCollection<JournaalPost> _journaalPosten;
        //private JournaalPostLijn _selectedJournaalPostLijn;
        private Journaal _selectedJournaal;
        public JournalenViewModel(IDataService dataService)
        {
            _dataService = dataService;
            Journalen = new ObservableCollection<Journaal>(_dataService.GeefAlleJournalen());
            if (Journalen.Count() > 0) SelectedJournaal = Journalen[0];
          //  JournaalPosten = new ObservableCollection<JournaalPost>(_dataService.GeefJournaalPostenVoorJournaalId((SelectedJournaal.Id)));
          //  ToonJournaalPostenCommand = new RelayCommand(GeefJournaalPosten);
        }

        //private void GeefJournaalPosten()
        //{
        //    if (SelectedJournaal !=null)
        //         JournaalPosten = new ObservableCollection<JournaalPost>(_dataService.GeefJournaalPostenVoorJournaalId(SelectedJournaal.Id));
        //}

        //public ICommand ToonJournaalPostenCommand { get; private set; }
        public Journaal SelectedJournaal
        {
            get { return _selectedJournaal; }
            set { OnPropertyChanged(ref _selectedJournaal, value); 
        }
        }
        public ObservableCollection<Journaal> Journalen
        {
            get { return _journalen; }
            set { OnPropertyChanged(ref _journalen, value); }
        }
        //public ObservableCollection<JournaalPost> JournaalPosten
        //{
        //    get { return _journaalPosten; }
        //    set { OnPropertyChanged(ref _journaalPosten, value); }
        //}
    }
}
