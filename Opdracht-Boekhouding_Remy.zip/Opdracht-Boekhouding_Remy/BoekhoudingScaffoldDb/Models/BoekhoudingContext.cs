﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace BoekhoudingScaffoldDb.Models
{
    public partial class BoekhoudingContext : DbContext
    {
        public BoekhoudingContext()
        {
        }

        public BoekhoudingContext(DbContextOptions<BoekhoudingContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DbDocumentNummer> DocumentNummer { get; set; }
        public virtual DbSet<DbGrootboekRekening> GrootboekRekening { get; set; }
        public virtual DbSet<DbJournaal> Journaal { get; set; }
        public virtual DbSet<DbJournaalPost> JournaalPost { get; set; }
        public virtual DbSet<DbJournaalPostHist> JournaalPostHist { get; set; }
        public virtual DbSet<DbJournaalPostLijn> JournaalPostLijn { get; set; }
        public virtual DbSet<DbJournaalType> JournaalType { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.;Database=Data Source=.;Initial Catalog=Boekhouding;Integrated Security=True;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DbDocumentNummer>(entity =>
            {
                entity.Property(e => e.DocPattern)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DocPrefix)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.DocType)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DbGrootboekRekening>(entity =>
            {
                entity.HasIndex(e => e.Code)
                    .HasName("IX_GrootboekRekening");

                entity.Property(e => e.BeginWaarde)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Klasse)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Klasse2)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Klasse3)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Naam)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.SorteerKolom)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DbJournaalPost>(entity =>
            {
                entity.Property(e => e.BoekDatum)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Omschrijving)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Referentie)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Journaal)
                    .WithMany(p => p.JournaalPost)
                    .HasForeignKey(d => d.JournaalId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JournaalPost_JournaalType");
            });

            modelBuilder.Entity<DbJournaalPostHist>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.CD)
                    .HasColumnName("C/D")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Omschrijving)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Referentie)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DbJournaalPostLijn>(entity =>
            {
                entity.Property(e => e.Cd)
                    .IsRequired()
                    .HasColumnName("CD")
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Omschrijving).HasMaxLength(500);

                entity.Property(e => e.Referentie).HasMaxLength(500);

                entity.HasOne(d => d.JournaalPost)
                    .WithMany(p => p.JournaalPostLijn)
                    .HasForeignKey(d => d.JournaalPostId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JournaalPostLijn_JournaalPost");

                entity.HasOne(d => d.Rekening)
                    .WithMany(p => p.JournaalPostLijn)
                    .HasForeignKey(d => d.RekeningId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JournaalPostLijn_GrootboekRekening");
            });

            modelBuilder.Entity<DbJournaalType>(entity =>
            {
                entity.HasOne(d => d.ItemTypeNavigation)
                    .WithMany(p => p.JournaalType)
                    .HasForeignKey(d => d.ItemType)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JournaalType_Journaal");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
