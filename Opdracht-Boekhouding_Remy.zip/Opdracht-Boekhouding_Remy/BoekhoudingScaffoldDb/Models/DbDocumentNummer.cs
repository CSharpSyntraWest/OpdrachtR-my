﻿using System;
using System.Collections.Generic;

namespace BoekhoudingScaffoldDb.Models
{
    public partial class DbDocumentNummer
    {
        public int Id { get; set; }
        public string DocType { get; set; }
        public string DocPrefix { get; set; }
        public string DocPattern { get; set; }
    }
}
