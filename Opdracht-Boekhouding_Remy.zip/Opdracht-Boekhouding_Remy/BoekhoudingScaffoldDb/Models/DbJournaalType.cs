﻿using System;
using System.Collections.Generic;

namespace BoekhoudingScaffoldDb.Models
{
    public partial class DbJournaalType
    {
        public DbJournaalType()
        {
            JournaalPost = new HashSet<DbJournaalPost>();
        }

        public int Id { get; set; }
        public int ItemType { get; set; }
        public string Naam { get; set; }

        public virtual DbJournaal ItemTypeNavigation { get; set; }
        public virtual ICollection<DbJournaalPost> JournaalPost { get; set; }
    }
}
