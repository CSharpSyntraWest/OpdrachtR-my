﻿using System;
using System.Collections.Generic;

namespace BoekhoudingScaffoldDb.Models
{
    public partial class DbJournaalPost
    {
        public DbJournaalPost()
        {
            JournaalPostLijn = new HashSet<DbJournaalPostLijn>();
        }

        public int Id { get; set; }
        public DateTime? BoekDatum { get; set; }
        public int? DocId { get; set; }
        public string Omschrijving { get; set; }
        public string Referentie { get; set; }
        public int VolgNr { get; set; }
        public int JournaalId { get; set; }

        public virtual DbJournaalType Journaal { get; set; }
        public virtual ICollection<DbJournaalPostLijn> JournaalPostLijn { get; set; }
    }
}
