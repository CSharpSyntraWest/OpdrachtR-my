﻿using System;
using System.Collections.Generic;

namespace BoekhoudingScaffoldDb.Models
{
    public partial class DbJournaal
    {
        public DbJournaal()
        {
            JournaalType = new HashSet<DbJournaalType>();
        }

        public int Id { get; set; }
        public int Boekjaar { get; set; }
        public int? JournaalTypeId { get; set; }

        public virtual ICollection<DbJournaalType> JournaalType { get; set; }
    }
}
