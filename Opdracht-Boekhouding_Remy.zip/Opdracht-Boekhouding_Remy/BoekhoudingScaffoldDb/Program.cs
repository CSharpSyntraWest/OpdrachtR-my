﻿//using BoekhoudingScaffoldDb.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BoekhoudingScaffoldDb
{
    class Program
    {
        static void Main(string[] args)
        {
            //BoekhoudingContext db = new BoekhoudingContext();
            //List<DbGrootboekRekening> rekeningen = db.GrootboekRekening.ToList();
            //foreach(DbGrootboekRekening r in rekeningen)
            //{
            //    Console.WriteLine(r.Naam);

            //}
        }
    }
}
